import 'dart:collection';

import 'node.dart';

class InsertionOperations {
  /// Level order insertion using queue (iterative)
  TreeNode<T>? insertLevelOrder<T>(TreeNode<T>? root, T value) {
    if (root == null) return TreeNode(value);

    final queue = Queue<TreeNode<T>>();
    queue.add(root);

    while (queue.isNotEmpty) {
      final current = queue.removeFirst();

      if (current.left == null) {
        current.left = TreeNode(value);
        break;
      } else {
        queue.add(current.left!);
      }

      if (current.right == null) {
        current.right = TreeNode(value);
        break;
      } else {
        queue.add(current.right!);
      }
    }

    return root;
  }

  /// Level order insertion (recursive)
  TreeNode<T>? insertLevelOrderRecursive<T>(TreeNode<T>? root, T value) {
    if (root == null) return TreeNode(value);
    
    if (_insertRecursiveHelper(root, value)) {
      return root;
    }
    return root;
  }

  bool _insertRecursiveHelper<T>(TreeNode<T> node, T value) {
    if (node.left == null) {
      node.left = TreeNode(value);
      return true;
    }
    if (node.right == null) {
      node.right = TreeNode(value);
      return true;
    }

    return _insertRecursiveHelper(node.left!, value) || 
           _insertRecursiveHelper(node.right!, value);
  }
}