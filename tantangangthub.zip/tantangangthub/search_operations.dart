import 'node.dart';

class SearchOperations {
  /// Linear search to find a node with target value
  TreeNode<T>? findNode<T>(TreeNode<T>? node, T target) {
    if (node == null) return null;
    if (node.value == target) return node;

    final leftResult = findNode(node.left, target);
    if (leftResult != null) return leftResult;

    return findNode(node.right, target);
  }
}