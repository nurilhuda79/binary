import 'binary_tree.dart';

void main() {
  final tree = BinaryTree<int>();

  // Insert nodes
  tree.insertLevelOrder(1);
  tree.insertLevelOrder(2);
  tree.insertLevelOrder(3);
  tree.insertLevelOrder(4);
  tree.insertLevelOrder(5);

  print('Initial tree:');
  tree.printTree();

  // Insert using recursive method
  tree.insertLevelOrderRecursive(6);
  tree.insertLevelOrderRecursive(7);

  print('\nAfter recursive insertion:');
  tree.printTree();

  // Insert after specific node
  tree.insertAfter(2, 8);
  tree.insertAfter(3, 9);

  print('\nAfter targeted insertion:');
  tree.printTree();
}