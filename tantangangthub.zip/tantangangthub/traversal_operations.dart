import 'node.dart';

class TraversalOperations {
  /// In-order traversal using stack
  List<T> inOrder<T>(TreeNode<T>? root) {
    final result = <T>[];
    final stack = <TreeNode<T>>[];
    var current = root;

    while (current != null || stack.isNotEmpty) {
      while (current != null) {
        stack.add(current);
        current = current.left;
      }
      current = stack.removeLast();
      result.add(current.value);
      current = current.right;
    }

    return result;
  }

  /// Pre-order traversal using stack
  List<T> preOrder<T>(TreeNode<T>? root) {
    if (root == null) return [];
    
    final result = <T>[];
    final stack = <TreeNode<T>>[root];

    while (stack.isNotEmpty) {
      final current = stack.removeLast();
      result.add(current.value);

      if (current.right != null) stack.add(current.right!);
      if (current.left != null) stack.add(current.left!);
    }

    return result;
  }

  /// Post-order traversal using two stacks
  List<T> postOrder<T>(TreeNode<T>? root) {
    if (root == null) return [];
    
    final result = <T>[];
    final stack1 = <TreeNode<T>>[root];
    final stack2 = <TreeNode<T>>[];

    while (stack1.isNotEmpty) {
      final current = stack1.removeLast();
      stack2.add(current);

      if (current.left != null) stack1.add(current.left!);
      if (current.right != null) stack1.add(current.right!);
    }

    while (stack2.isNotEmpty) {
      result.add(stack2.removeLast().value);
    }

    return result;
  }
}