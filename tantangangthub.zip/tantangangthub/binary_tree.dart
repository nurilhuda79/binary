import 'node.dart';
import 'insertion_operations.dart';
import 'search_operations.dart';
import 'traversal_operations.dart';

class BinaryTree<T> {
  TreeNode<T>? _root;
  final InsertionOperations _insertion = InsertionOperations();
  final TraversalOperations _traversal = TraversalOperations();
  final SearchOperations _search = SearchOperations();

  //c methods
  void insertLevelOrder(T value) {
    _root = _insertion.insertLevelOrder(_root, value);
  }

  void insertLevelOrderRecursive(T value) {
    _root = _insertion.insertLevelOrderRecursive(_root, value);
  }

  void insertAfter(T target, T newValue) {
    final targetNode = _search.findNode(_root, target);
    if (targetNode != null) {
      if (targetNode.left == null) {
        targetNode.left = TreeNode(newValue);
      } else if (targetNode.right == null) {
        targetNode.right = TreeNode(newValue);
      }
    }
  }

  List<T> inOrder() => _traversal.inOrder(_root);
  List<T> preOrder() => _traversal.preOrder(_root);
  List<T> postOrder() => _traversal.postOrder(_root);

  void printTree() {
    print('In-order: ${inOrder()}');
    print('Pre-order: ${preOrder()}');
    print('Post-order: ${postOrder()}');
  }
}